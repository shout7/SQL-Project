
--Group 4
--2501978042_Samuel Axel Widjaja
--2540132055_Christopher Walandi
--2501974353_Marco Tannando
--2502013050_Irgy Dwismara Putra


--3.
INSERT INTO MsStaff(StaffID, StaffName, StaffGender, StaffEmail, StaffPhone, StaffSalary)
VALUES ('MS001', 'Michael Tristan', 'Male', 'michael.s@mail.com', '08112645267',5000000)

INSERT INTO MsStaff(StaffID, StaffName, StaffGender, StaffEmail, StaffPhone, StaffSalary)
VALUES ('MS002', 'John Mikael', 'Male', 'john@mail.com', '08120197392',5000000)

INSERT INTO MsStaff(StaffID, StaffName, StaffGender, StaffEmail, StaffPhone, StaffSalary)
VALUES ('MS003', 'Michelle Chandra', 'Female', 'michelle@mail.com', '08581028932',6000000)

INSERT INTO MsStaff(StaffID, StaffName, StaffGender, StaffEmail, StaffPhone, StaffSalary)
VALUES ('MS004', 'Felicia Wati', 'Female', 'felicia11@mail.com', '08111081281',4000000)

INSERT INTO MsStaff(StaffID, StaffName, StaffGender, StaffEmail, StaffPhone, StaffSalary)
VALUES ('MS005', 'Chris Putra', 'Male', 'chris00@mail.com', '08131222811',7000000)

INSERT INTO MsStaff(StaffID, StaffName, StaffGender, StaffEmail, StaffPhone, StaffSalary)
VALUES ('MS006', 'David Wirawan', 'Male', 'davidsss@mail.com', '08129099121',5500000)

INSERT INTO MsStaff(StaffID, StaffName, StaffGender, StaffEmail, StaffPhone, StaffSalary)
VALUES ('MS007', 'Vanessa Christy', 'Female', 'vanessaas@mail.com', '08121383138',9000000)

INSERT INTO MsStaff(StaffID, StaffName, StaffGender, StaffEmail, StaffPhone, StaffSalary)
VALUES ('MS008', 'Wilson Anderson', 'Male', 'wilson01@mail.com', '08131098234',10000000)

INSERT INTO MsStaff(StaffID, StaffName, StaffGender, StaffEmail, StaffPhone, StaffSalary)
VALUES ('MS009', 'Tristan Halim', 'Male', 'toto@mail.com', '08127877629',13000000)

INSERT INTO MsStaff(StaffID, StaffName, StaffGender, StaffEmail, StaffPhone, StaffSalary)
VALUES ('MS010', 'Edbert Jo', 'Male', 'edbert.s@mail.com', '08121000289',50000000)




--MsJacket
INSERT INTO MsJacket(JacketID, BrandID, BrandName, TypeID, TypeName, PurchasePrice, SalesPrice, Stock)
VALUES ('MJ001', 'JB001','Balencyaga','JT001','Rain Coat',3000000,7000000,250)

INSERT INTO MsJacket(JacketID, BrandID, BrandName, TypeID, TypeName, PurchasePrice, SalesPrice, Stock)
VALUES ('MJ002', 'JB002','Guccy','JT002','Bomber',6000000,8000000,300)

INSERT INTO MsJacket(JacketID, BrandID, BrandName, TypeID, TypeName, PurchasePrice, SalesPrice, Stock)
VALUES ('MJ003', 'JB003','Uniqla','JT003','Trucker',250000, 2500000, 150)

INSERT INTO MsJacket(JacketID, BrandID, BrandName, TypeID, TypeName, PurchasePrice, SalesPrice, Stock)
VALUES ('MJ004', 'JB004','Niku','JT004','Denim',500000,1000000,110)

INSERT INTO MsJacket(JacketID, BrandID, BrandName, TypeID, TypeName, PurchasePrice, SalesPrice, Stock)
VALUES ('MJ005', 'JB005','Adidus','JT005','Hoodie',1500000,3500000,125)

INSERT INTO MsJacket(JacketID, BrandID, BrandName, TypeID, TypeName, PurchasePrice, SalesPrice, Stock)
VALUES ('MJ006', 'JB006','H&N','JT006','Parka',2000000,4000000,200)

INSERT INTO MsJacket(JacketID, BrandID, BrandName, TypeID, TypeName, PurchasePrice, SalesPrice, Stock)
VALUES ('MJ007', 'JB007','Versauce','JT007','Pea Coat',1000000,5200000,135)

INSERT INTO MsJacket(JacketID, BrandID, BrandName, TypeID, TypeName, PurchasePrice, SalesPrice, Stock)
VALUES ('MJ008', 'JB008','Hermas','JT008','Trench Coat',4500000,9500000,145)

INSERT INTO MsJacket(JacketID, BrandID, BrandName, TypeID, TypeName, PurchasePrice, SalesPrice, Stock)
VALUES ('MJ009', 'JB009','Prady','JT009','Crombie Coat',2500000,7500000,100)

INSERT INTO MsJacket(JacketID, BrandID, BrandName, TypeID, TypeName, PurchasePrice, SalesPrice, Stock)
VALUES ('MJ010', 'JB010','Suprene','JT010','Varsity',1000000,4000000,90)

--Msvendor
INSERT INTO MsVendor (VendorID, VendorName, VendorEmail, VendorPhone, VendorAddress)
VALUES ('MV001', 'Erico Supplier.co', 'eric.sc@mail.com','0822163809', 'Alam Sutera Street No 552')

INSERT INTO MsVendor (VendorID, VendorName, VendorEmail, VendorPhone, VendorAddress)
VALUES ('MV002', 'Brada Supplier', 'brada.br@mail.com','0822019302', 'Alam Indah Street No 102')

INSERT INTO MsVendor (VendorID, VendorName, VendorEmail, VendorPhone, VendorAddress)
VALUES ('MV003', 'Rego Supplier', 'rego.rg@mail.com','0821029344', 'Sutra Niaga Street No 5')

INSERT INTO MsVendor (VendorID, VendorName, VendorEmail, VendorPhone, VendorAddress)
VALUES ('MV004', 'Qne Supplier', 'qne@mail.com','082219223', 'Taman Pabuaran Street No 3')

INSERT INTO MsVendor (VendorID, VendorName, VendorEmail, VendorPhone, VendorAddress)
VALUES ('MV005', 'Embark Supplier', 'embark@mail.com','082193021', 'Pabuaran Indah Street No 10')

INSERT INTO MsVendor (VendorID, VendorName, VendorEmail, VendorPhone, VendorAddress)
VALUES ('MV006', 'Sail Supplier', 'sail@mail.com','0821948679', 'Sudirman Street No 30')

INSERT INTO MsVendor (VendorID, VendorName, VendorEmail, VendorPhone, VendorAddress)
VALUES ('MV007', 'Algo Supplier', 'algo@mail.com','0822495869', 'Gatot Subroto Street No 35')

INSERT INTO MsVendor (VendorID, VendorName, VendorEmail, VendorPhone, VendorAddress)
VALUES ('MV008', 'Meta Supplier', 'meta@mail.com','0822102340', 'Alam Desa Street No 1')

INSERT INTO MsVendor (VendorID, VendorName, VendorEmail, VendorPhone, VendorAddress)
VALUES ('MV009', 'Santo Supplier', 'santo@mail.com','0822304539', 'Mangkubumi Street No 9')

INSERT INTO MsVendor (VendorID, VendorName, VendorEmail, VendorPhone, VendorAddress)
VALUES ('MV010', 'Ready Supplier', 'ready@mail.com','0822112034', 'Supratman Street No 15')


--MsCustomer
INSERT INTO MsCustomer (CustomerID, CustomerName, CustomerGender, CustomerEmail, CustomerPhone, CustomerAddress)
VALUES ('MC001', 'Jason Susanto', 'Male', 'jason.hs@mail.com', '087875959201', 'Boulevard Street No 15')

INSERT INTO MsCustomer (CustomerID, CustomerName, CustomerGender, CustomerEmail, CustomerPhone, CustomerAddress)
VALUES ('MC002', 'Cindy Garcia', 'Female', 'cindy.88@mail.com', '082384591512', 'High palace Street No 23')

INSERT INTO MsCustomer (CustomerID, CustomerName, CustomerGender, CustomerEmail, CustomerPhone, CustomerAddress)
VALUES ('MC003', 'Kevin Michael', 'Male', 'Kevin172@mail.com', '083257457390', 'Heaven Street No 01')

INSERT INTO MsCustomer (CustomerID, CustomerName, CustomerGender, CustomerEmail, CustomerPhone, CustomerAddress)
VALUES ('MC004', 'Denver John', 'Male', 'denver928@mail.com', '082017482537', 'Richie Street No 22')

INSERT INTO MsCustomer (CustomerID, CustomerName, CustomerGender, CustomerEmail, CustomerPhone, CustomerAddress)
VALUES ('MC005', 'Cheris Kurnia', 'Female', 'Cheris01@mail.com', '082833929184', 'High Street No 35')

INSERT INTO MsCustomer (CustomerID, CustomerName, CustomerGender, CustomerEmail, CustomerPhone, CustomerAddress)
VALUES ('MC006', 'Nathan Halim', 'Male', 'Nathan3@mail.com', '082374859281', 'V Street No 88')

INSERT INTO MsCustomer (CustomerID, CustomerName, CustomerGender, CustomerEmail, CustomerPhone, CustomerAddress)
VALUES ('MC007', 'Gaby Wijaya', 'Female', 'gaby23@mail.com', '082390485829', 'Nice Street No 83')

INSERT INTO MsCustomer (CustomerID, CustomerName, CustomerGender, CustomerEmail, CustomerPhone, CustomerAddress)
VALUES ('MC008', 'Gabriella Tanjaya', 'Female', 'Gabriella23@mail.com', '029347461830', 'VII  Street No 00')

INSERT INTO MsCustomer (CustomerID, CustomerName, CustomerGender, CustomerEmail, CustomerPhone, CustomerAddress)
VALUES ('MC009', 'Feliss law', 'Female', 'Feliss22@mail.com', '087892839405', 'Harvy Street No 15')

INSERT INTO MsCustomer (CustomerID, CustomerName, CustomerGender, CustomerEmail, CustomerPhone, CustomerAddress)
VALUES ('MC010', 'Nathaniel Tan', 'Male', 'Nathaniel@mail.com', '08783938263', 'Boulevard Street No 30')



--PurchaseTransaction
INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH020', 'MS003', 'MJ008', 'MV008', '2022-07-06')

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH014', 'MS004', 'MJ001', 'MV006', '2022-04-11')

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH031', 'MS002', 'MJ005', 'MV002', '2021-11-23')

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH030', 'MS009', 'MJ006', 'MV002', '2021-10-15')

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH033', 'MS010', 'MJ002', 'MV001', '2021-12-11')

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH021', 'MS001', 'MJ003', 'MV005', '2021-03-30')

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH002', 'MS004', 'MJ010', 'MV010', '2021-05-28')

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH010', 'MS005', 'MJ003', 'MV003', '2021-01-02')

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH005', 'MS003', 'MJ009', 'MV010', '2021-06-25')

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH051', 'MS007', 'MJ007', 'MV007', '2021-07-17')

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH049', 'MS004', 'MJ002', 'MV003', '2021-05-23')

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH017', 'MS001', 'MJ008', 'MV004', '2021-03-12')

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH012', 'MS010', 'MJ001', 'MV004', '2021-04-12')

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH027', 'MS001', 'MJ004', 'MV008', '2021-05-05')


--PurchaseDetail
INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH020', 'MJ008', 30)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH014', 'MJ006', 3)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH049', 'MJ008', 25)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH031', 'MJ005', 50)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH030', 'MJ006', 35)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH033', 'MJ002', 5)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH021', 'MJ003', 10)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH002', 'MJ010', 15)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH010', 'MJ003', 9)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH005', 'MJ009', 11)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH051', 'MJ007', 15)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH049', 'MJ002', 19)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH017', 'MJ008', 21)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH012', 'MJ001', 3)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH027', 'MJ004', 3)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH027', 'MJ005', 10)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH017', 'MJ005', 49)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH020', 'MJ007', 12)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH031', 'MJ008', 5)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH027', 'MJ010', 27)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH017', 'MJ004', 10)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH051', 'MJ001', 12)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH049', 'MJ006', 7)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH017', 'MJ002', 15)

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH005', 'MJ004', 29)

--SalesTransaction
INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH110', 'MS002', 'MC010', 'MJ002', '2022-05-26')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH120', 'MS007', 'MC002', 'MJ001', '2022-05-21')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH066', 'MS010', 'MC003', 'MJ001', '2022-04-02')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH077', 'MS001', 'MC006', 'MJ003', '2022-02-17')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH009', 'MS005', 'MC004', 'MJ005', '2022-03-11')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH102', 'MS003', 'MC003', 'MJ001', '2022-07-30')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH101', 'MS002', 'MC001', 'MJ008', '2022-02-18')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH067', 'MS009', 'MC007', 'MJ004', '2022-07-08')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH038', 'MS008', 'MC009', 'MJ007', '2022-03-10')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH007', 'MS004', 'MC008', 'MJ010', '2022-05-18')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH131', 'MS006', 'MC008', 'MJ009', '2022-04-28')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH014', 'MS009', 'MC001', 'MJ010', '2022-02-15')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH063', 'MS001', 'MC005', 'MJ003', '2022-03-29')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH037', 'MS002', 'MC003', 'MJ002', '2022-05-21')

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH010', 'MS007', 'MC010', 'MJ005', '2022-01-19')
select *From SalesDetail

--SalesDetail
INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH110', 'MJ002', 10)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH120', 'MJ001', 15)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH066', 'MJ001', 12)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH077', 'MJ003', 10)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH009', 'MJ005', 12)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH102', 'MJ001', 13)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH101', 'MJ008', 10)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH067', 'MJ004', 18)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH038', 'MJ007', 20)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH007', 'MJ010', 22)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH131', 'MJ009', 10)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH014', 'MJ010', 20)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH063', 'MJ003', 30)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH037', 'MJ002', 40)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH010', 'MJ005', 50)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH067', 'MJ002', 32)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH038', 'MJ010', 20)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH007', 'MJ003', 8)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH131', 'MJ006', 40)

INSERT INTO SalesDetail (SalesID, JacketID, SalesQuantity)
VALUES ('SH014', 'MJ009', 30)

INSERT INTO SalesDetail(SalesID, JacketID, SalesQuantity)
VALUES ('SH063','MJ007',32)

INSERT INTO SalesDetail(SalesID, JacketID, SalesQuantity)
VALUES ('SH037','MJ008',2)

INSERT INTO SalesDetail(SalesID, JacketID, SalesQuantity)
VALUES ('SH010','MJ004',17)

INSERT INTO SalesDetail(SalesID, JacketID, SalesQuantity)
VALUES ('SH102','MJ002',5)

INSERT INTO SalesDetail(SalesID, JacketID, SalesQuantity)
VALUES ('SH101','MJ005',12)