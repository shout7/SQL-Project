
--Group 4
--2501978042_Samuel Axel Widjaja
--2540132055_Christopher Walandi
--2501974353_Marco Tannando
--2502013050_Irgy Dwismara Putra



--4.
--Staff 1 membeli jacket dengan tipe bomber merk guccy pada qne supplier sebanyak 10 jacket pada tanggal 9 Juni 2022 dengan harga 100.000.000

INSERT INTO PurchaseTransaction (PurchaseID, StaffID, JacketID, VendorID, PurchaseDate)
VALUES ('PH070', 'MS001', 'MJ002', 'MV004', '2022-06-09')

INSERT INTO PurchaseDetail (PurchaseID, JacketID, PurchaseQuantity)
VALUES ('PH070', 'MJ002', '10')

INSERT INTO MsJacket(JacketID, BrandID, BrandName, TypeID, TypeName, PurchasePrice, SalesPrice, Stock)
VALUES ('MJ011', 'JB002','Guccy','JT002','Bomber','100.000.000','250.000.000','10')


--Setelah ada stock, customer membeli 10 jacket bomber dengan merk guccy dari staff 1 pada tanggal 10 juni 2022

INSERT INTO SalesTransaction(SalesID, StaffID, CustomerID, JacketID, SalesDate)
VALUES ('SH069', 'MS001', 'MC011', 'MJ002', '2022-06-10')

INSERT INTO SalesDetail(SalesID, JacketID, SalesQuantity)
VALUES ('SH069','MJ002','10')

DELETE
FROM MsJacket
WHERE JacketID = 'MJ011'

INSERT INTO MsCustomer (CustomerID, CustomerName, CustomerGender, CustomerEmail, CustomerPhone, CustomerAddress)
VALUES ('MC011', 'Jonathan', 'Male', 'Jojo@mail.com', '0813128901', 'Happy Street No 82')