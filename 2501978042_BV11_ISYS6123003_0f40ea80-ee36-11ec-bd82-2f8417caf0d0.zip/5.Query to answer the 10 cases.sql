--Group 4
--2501978042_Samuel Axel Widjaja
--2540132055_Christopher Walandi
--2501974353_Marco Tannando
--2502013050_Irgy Dwismara Putra



--5.

--1.	Display StaffID, StaffName, and TotalJacketSold (obtained from the sum of SalesQuantity) 
--for every male customer and transaction that occurred in February.

SELECT ms.StaffID, StaffName, [TotalJacketSold] = SUM (SalesQuantity)
FROM MsStaff ms JOIN SalesTransaction st ON ms.StaffID = st.StaffID  JOIN SalesDetail sd ON sd.SalesID = st.SalesID
JOIN MsCustomer mc ON st.CustomerID = mc.CustomerID
WHERE CustomerGender = 'Male' AND DATENAME(MONTH, SalesDate) = 'February'
GROUP BY  ms.StaffID, StaffName

--2.	Display StaffID, StaffName, VendorName, and TotalTransaction (obtained from the total of purchase transactions) for every purchase transaction 
--that occurred on Monday and was purchased by female staff.
SELECT ms.StaffID, StaffName, VendorName, [TotalTransaction] = COUNT (PurchaseID)
FROM MsStaff ms JOIN PurchaseTransaction pt ON ms.StaffID = pt.StaffID JOIN MsVendor mv ON mv.VendorID = pt.VendorID
WHERE StaffGender = 'Female' AND  DATENAME(WEEKDAY,PurchaseDate) IN ('Monday')
GROUP BY ms.StaffID, StaffName, VendorName


--3.	Display VendorID, VendorName, VendorEmail, TotalJacketPurchased (obtained from the sum of PurchaseQuantity), and TotalTransaction 
--(obtained from the total number of different jackets that has been sold by vendor) for every purchase transaction that occurred on Tuesday and at least 3 months ago.
SELECT mv.VendorID, VendorName, VendorEmail, [TotalJacketPurchased] = SUM(PurchaseQuantity), [TotalTransaction] = COUNT (pt.PurchaseID)
FROM MsVendor mv JOIN PurchaseTransaction pt ON mv.VendorID = pt.VendorID JOIN PurchaseDetail pd ON pt.PurchaseID = pd.PurchaseID
WHERE DATENAME(WEEKDAY,PurchaseDate) IN ('Tuesday') AND DATEDIFF(MONTH, PurchaseDate, PurchaseDate) <=3
GROUP BY mv.VendorID, VendorName, VendorEmail


--4.	Display StaffID, StaffName, and TotalJacketSold (obtained from the sum of SalesQuantity) for every sales transaction that occurred at 
--least 6 months ago and by the staff that has 3 or more total transactions.
SELECT ms.StaffID, StaffName, [TotalJacketSold] = SUM(SalesQuantity)
FROM MsStaff ms JOIN SalesTransaction st ON ms.StaffID = st.StaffID JOIN SalesDetail sd ON st.SalesID = sd.SalesID
WHERE DATEDIFF(MONTH, SalesDate, SalesDate) <=6
GROUP BY ms.StaffID, StaffName
HAVING COUNT (st.SalesID) >=3


--5.	Display StaffName (obtained from the first name of StaffName), StaffSalary, VendorName, and Year (obtained from the year of PurchaseDate) 
--for every purchase transaction that occurred in 2021 and served by a staff whose salary is higher than the average salary of every staff.
--(alias subquery)

SELECT LEFT(StaffName, CHARINDEX(' ',StaffName)) AS [StaffName], StaffSalary, VendorName, [Year] = YEAR(PurchaseDate)
FROM MsStaff ms JOIN PurchaseTransaction pt ON ms.StaffID = pt.StaffID JOIN MsVendor mv ON pt.VendorID = mv.VendorID,
	(
	SELECT AVG (StaffSalary) AS avgSalary
	FROM MsStaff
	) x
WHERE YEAR (PurchaseDate) = '2021'  AND StaffSalary > x.avgSalary


--6.	Display StaffName, StaffPhone (obtained by replacing StaffPhone first character into �+62�), CustomerName, and SalesDate 
--(obtained from SalesDate with �Mon dd, yyyy� format) for every sales transaction that occurred in May and served by a staff whose salary is equal to the minimum salary of every staff.
--(alias subquery)

SELECT StaffName, '+62'+SUBSTRING(StaffPhone,2,15) AS [StaffPhone], CustomerName ,CONVERT(VARCHAR,SalesDate,106) AS [SalesDate]
FROM MsStaff ms JOIN SalesTransaction st ON ms.StaffID = st.StaffID JOIN MsCustomer mc ON st.CustomerID = mc.CustomerID,
	(
	SELECT MIN(StaffSalary) AS MinSalary
	FROM MsStaff
	) x
WHERE StaffSalary = x.MinSalary AND DATENAME(MONTH, SalesDate) = 'May'


--7.	Display CustomerName, CustomerGender (obtained from the first letter of CustomerGender), CustomerAddress, and TotalSalesPrice 
--(obtained by adding �Rp. � of the sum of JacketSalesPrice multiple by SalesQuantity of Jacket in sales transaction ) for every sales 
--transaction that not occurred in March and bought by customer whose total jacket bought is equal to the maximum total jacket bought of every customer. 
--(alias subquery)

SELECT CustomerName, SUBSTRING(CustomerGender,1,1) AS [CustomerGender], CustomerAddress, [TotalSalesPrice]= 'Rp.'+CONVERT(VARCHAR,SUM(SalesPrice*SalesQuantity))
FROM MsCustomer mc JOIN SalesTransaction st ON mc.CustomerID = st.CustomerID JOIN MsJacket mj ON st.JacketID = mj.JacketID
JOIN SalesDetail sd ON mj.JacketID = sd.JacketID,
	(
	SELECT MAX(SalesQuantity) AS maxSales
	FROM SalesDetail
	)x
WHERE DATENAME(MONTH,SalesDate) NOT IN ('March') AND SalesQuantity = x.maxSales
GROUP BY CustomerName, CustomerGender, CustomerAddress


--8.	Display PurchaseID, PurchaseDate, StaffID, StaffName (obtained from the first name of StaffName), and StaffEmail 
--for every purchase transaction that occurred on Monday and purchased by staff whose total jacket purchased is equal to the 
--minimum total jacket purchased of every staff.
--(alias subquery)

SELECT pt.PurchaseID, PurchaseDate, ms.StaffID, LEFT(StaffName, CHARINDEX(' ',StaffName)) AS [StaffName], StaffEmail
FROM PurchaseTransaction pt JOIN MsStaff ms ON pt.StaffID = ms.StaffID JOIN PurchaseDetail pd ON pt.PurchaseID = pd.PurchaseID,
	(
	SELECT MIN(PurchaseQuantity) AS MinPurchase
	FROM PurchaseDetail
	)x
WHERE DATENAME(WEEKDAY,PurchaseDate) IN ('Monday') AND PurchaseQuantity = x.MinPurchase



--9.	Create a view named �JacketPurchase� to display PurchaseID, PurchaseMonth (obtained from the month name of PurchaseDate), 
--TotalJacketBrand (obtained from the total of jacket brand), and TotalPurchasePrice (obtained from the sum of JacketPurchasePrice multiple 
--by PurchaseQuantity of Jacket in purchase transaction) for every purchase transaction that occurred in June and has total purchase price higher than 5.000.000.
GO
CREATE VIEW [JacketPurchase] AS
SELECT pt.PurchaseID, [PurchaseMonth] = DATENAME(MONTH, DATEADD(MONTH, 1, PurchaseDate)) , [TotalJacketBrand] = COUNT(BrandName), [TotalPurchasePrice] = SUM(PurchasePrice*PurchaseQuantity)
FROM PurchaseTransaction pt JOIN MsJacket mj ON pt.JacketID = mj.JacketID JOIN PurchaseDetail pd ON pt.PurchaseID = pd.PurchaseID
WHERE DATENAME(MONTH, PurchaseDate) = 'June' 
GROUP BY pt.PurchaseID, PurchaseDate
HAVING SUM(PurchasePrice*PurchaseQuantity) > 5000000



--10.	Create a view named �JacketSales� to display SalesID, SalesDate (obtained from SalesDate with �Mon dd, yyyy� format), TotalJacketType 
--(obtained from the total of jacket type), and TotalSalesPrice (obtained by adding �Rp. � of the sum of JacketSalesPrice multiple by SalesQuantity of Jacket in sales transaction)  
--for every sales transaction that occurred in July but not on Friday.
GO
CREATE VIEW [JacketSales] AS
SELECT st.SalesID,CONVERT(VARCHAR,SalesDate,107) AS [SalesDate], [TotalJacketType] = COUNT (TypeName), [TotalSalesPrice] = 'Rp.'+CONVERT(VARCHAR,SUM(SalesPrice*SalesQuantity))
FROM SalesTransaction st JOIN MsJacket mj ON st.JacketID = mj.JacketID JOIN SalesDetail sd ON st.SalesID = sd.SalesID
WHERE DATENAME(MONTH, SalesDate) = 'July' AND DATENAME(WEEKDAY,SalesDate) NOT IN ('Monday') 
GROUP BY st.SalesID, SalesDate